/* גשר בין המעטפת (index.html) לבין האפליקציות הפנימיות. מדבר רק דרך postMessage. */
(function(){
  'use strict';
  if(window.parent===window)return;
  var APP=window.__APP||'app';
  var KEY=APP==='maslul'?'mukhan-lamivchan-v1':'vocab_mine_v1';
  function send(o){try{o.__maslul=1;o.app=APP;window.parent.postMessage(o,'*');}catch(e){}}
  function lsGet(){try{return localStorage.getItem(KEY);}catch(e){return null;}}
  function clickTab(t){
    var b=APP==='maslul'?document.querySelector('#tabs [data-t="'+t+'"]'):document.querySelector('nav.tabs [data-tab="'+t+'"]');
    if(b){b.click();return true;}return false;
  }
  window.addEventListener('message',function(e){
    if(e.source!==window.parent)return;
    var m=e.data; if(!m||m.__maslul!==1)return;
    try{
      if(m.t==='dump'){send({t:'dump',id:m.id,data:lsGet()});}
      else if(m.t==='summary'){
        var s=window.__summary?window.__summary():null;
        send({t:'summary',id:m.id,data:s,raw:APP==='vocab'?lsGet():null});
      }
      else if(m.t==='tab'){send({t:'tabOk',id:m.id,ok:clickTab(m.tab)});}
      else if(m.t==='award'&&window.__award){window.__award(m.n,m.why);send({t:'awardOk',id:m.id});}
      else if(m.t==='restore'){try{localStorage.setItem(KEY,m.data);}catch(er){} send({t:'restoreOk',id:m.id}); setTimeout(function(){location.reload();},150);}
      else if(m.t==='wipe'){try{localStorage.removeItem(KEY);}catch(er){} send({t:'wipeOk',id:m.id}); setTimeout(function(){location.reload();},150);}
    }catch(err){send({t:'err',id:m.id,msg:String(err&&err.message||err)});}
  });
  send({t:'ready'});
})();
